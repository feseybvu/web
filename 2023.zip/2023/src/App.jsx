import { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";

function App() {
  const [tytul, setTytul] = useState("");
  const [rodzaj, setRodzaj] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(`tytuł: ${tytul}; rodzaj: ${rodzaj}`);
  };

  return (
    <div style={{ padding: "20px" }}>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="Film_Title">Tytuł filmu</label>
          <input
            type="text"
            id="Film_Title"
            className="form-control"
            value={tytul}
            onChange={(e) => setTytul(e.target.value)}
          />
        </div>

        <p></p>

        <div className="form-group">
          <label htmlFor="Film_Type">Rodzaj</label>
          <select
            id="Film_Type"
            className="form-select"
            value={rodzaj}
            onChange={(e) => setRodzaj(e.target.value)}
          >
            <option value="">-- wybierz --</option>
            <option value="Komedia">Komedia</option>
            <option value="Obyczajowy">Obyczajowy</option>
            <option value="Sensacyjny">Sensacyjny</option>
            <option value="Horror">Horror</option>
          </select>
        </div>

        <p></p>

        <button type="submit" className="btn btn-primary">
          Dodaj
        </button>
      </form>
    </div>
  );
}

export default App;
