import { useState } from "react";

const imagesData = [
  {id: 0, alt: "Mak", filename: "obraz1.jpg", category:1, downloads: 35},
  {id: 1, alt:"Bukiet", filename: "obraz2.jpg", category: 1, downloads: 43},
  {id: 2, alt:"Dalmatyńczyk", filename: "obraz3.jpg", category:2, downloads: 2},
  {id: 3, alt:"Świnka morska", filename: "obraz4.jpg", category:2, downloads: 53},
  {id: 4, alt:"Rotwailer", filename: "obraz5.jpg", category:2, downloads: 43},
  {id: 5, alt:"Audi", filename: "obraz6.jpg", category:3, downloads: 11},
  {id: 6, alt:"Kotki", filename: "obraz7.jpg", category:2, downloads: 22},
  {id: 7, alt:"Róża", filename: "obraz8.jpg", category:1, downloads: 33},
  {id: 8, alt:"Świnka morska", filename: "obraz9.jpg", category:2, downloads: 123},
  {id: 9, alt:"Foksterier", filename: "obraz10.jpg", category:2, downloads: 22},
  {id: 10, alt:"Szczeniak", filename: "obraz11.jpg", category:2, downloads: 12},
  {id: 11, alt:"Garbus", filename: "obraz12.jpg", category:3, downloads: 321}
];

function App() {
  const [photos, setPhotos] = useState(imagesData);
  const [showFlowers, setShowFlowers] = useState(true);
  const [showAnimals, setShowAnimals] = useState(true);
  const [showCars, setShowCars] = useState(true);

  const handleDownload = (id) => {
    setPhotos(
      photos.map((img) =>
        img.id === id ? { ...img, downloads: img.downloads + 1 } : img
      )
    );
  };

  const filteredPhotos = photos.filter((img) => {
    if (img.category === 1 && showFlowers) return true;
    if (img.category === 2 && showAnimals) return true;
    if (img.category === 3 && showCars) return true;
    return false;
  });

  const containerStyle = {
    padding: "20px",
    fontFamily: "Arial, sans-serif"
  };

  const switchesStyle = {
    marginBottom: "20px"
  };

  const galleryStyle = {
    display: "flex",
    flexWrap: "wrap",
    gap: "10px"
  };

  const photoStyle = {
    borderRadius: "10px",
    overflow: "hidden",
    width: "250px"
  };

  const imgStyle = {
    width: "100%",
    borderRadius: "10px"
  };

  const buttonStyle = {
    backgroundColor: "#007b2f",
    color: "white",
    border: "none",
    borderRadius: "5px",
    padding: "6px 12px",
    cursor: "pointer",
    marginBottom: "10px"
  };

  return (
    <div style={containerStyle}>
      <h1>Kategorie zdjęć</h1>

      <div style={switchesStyle}>
        <label style={{ marginRight: "10px" }}>
          <input
            type="checkbox"
            checked={showFlowers}
            onChange={(e) => setShowFlowers(e.target.checked)}
          />{" "}
          Kwiaty
        </label>

        <label style={{ marginRight: "10px" }}>
          <input
            type="checkbox"
            checked={showAnimals}
            onChange={(e) => setShowAnimals(e.target.checked)}
          />{" "}
          Zwierzęta
        </label>

        <label>
          <input
            type="checkbox"
            checked={showCars}
            onChange={(e) => setShowCars(e.target.checked)}
          />{" "}
          Samochody
        </label>
      </div>

      <div style={galleryStyle}>
        {filteredPhotos.map((img) => (
          <div key={img.id} style={photoStyle}>
            <img src={`./assets/${img.filename}`} alt={img.alt} style={imgStyle} />
            <h4>Pobrań: {img.downloads}</h4>
            <button onClick={() => handleDownload(img.id)} style={buttonStyle}>
              Pobierz
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
